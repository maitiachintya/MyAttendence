package com.example.myattendence.activity

import android.app.TimePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import com.example.myattendence.databinding.ActivityCheckInBinding
import java.text.SimpleDateFormat
import java.util.*

class CheckInActivity : AppCompatActivity() {
    private val calendar = Calendar.getInstance()
    private val timeFormatter = SimpleDateFormat("hh:mm a", Locale.US)
    private lateinit var binding: ActivityCheckInBinding
   /* private lateinit var checkInTimePicker: TimePicker
    private val allowedHour = 11 // Constraint: Check-in hour cannot be greater than 10 AM*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        binding = ActivityCheckInBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        // sharedPrefs = getSharedPreferences(sharedPrefsFileName, Context.MODE_PRIVATE)
        /* val layout =LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        checkInTimePicker = TimePicker(this)
        layout.addView(checkInTimePicker)*/
        binding.backBtn.setOnClickListener(View.OnClickListener {
            val viewActivityIntent = Intent(this@CheckInActivity, HomeActivity::class.java)
            startActivity(viewActivityIntent)
        })
        binding.checkTimeButton.setOnClickListener(View.OnClickListener {
            /*val selectedHour = checkInTimePicker.hour
            val selectedMinute = checkInTimePicker.minute
            onTimePickerClickListner(selectedHour, selectedMinute)*/
            showTimePicker()
        })
    }

    private fun showTimePicker() {
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMinute = calendar.get(Calendar.MINUTE)
        val timePickerDialog = TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                calendar.set(Calendar.MINUTE, minute)
                val checkInTime = calendar.timeInMillis
                // Create an Intent to pass the check-in time to the CheckOutActivity
                val intent = Intent(this, CheckOutActivity::class.java)
                intent.putExtra("checkInTime", checkInTime)
                startActivity(intent)
                binding.checkTimeButton.text = "Check-in Time: ${timeFormatter.format(calendar.time)}"
               /* if(isStartTime){
                    binding.selectetime.text = timeFormatter.toString()
                }*/
            },
            currentHour, currentMinute, false
        )
        timePickerDialog.show()
    }
}

    /*override fun onTimePickerClickListner(hour: Int, min: Int) {
        if (hour < allowedHour || (hour == allowedHour && min == 0)) {
            // Check-in time is valid
            showResult("Check-in time is valid.")
        } else {
            // Check-in time is greater than the allowed time
            showAlertDialog("Invalid Check-in Time", "Check-in time cannot be greater than $allowedHour:00 AM.")
        }
    }

    private fun showAlertDialog(title: String, message: String) {
        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle(title)
        alertDialogBuilder.setMessage(message)
        alertDialogBuilder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }

    private fun showResult(message: String) {
        Toast.makeText(this@CheckInActivity, message, Toast.LENGTH_LONG).show()
    }*/