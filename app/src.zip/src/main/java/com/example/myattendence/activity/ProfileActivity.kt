package com.example.myattendence.activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.myattendence.R
import com.example.myattendence.databinding.ActivityProfileBinding
import com.squareup.picasso.Picasso
import com.squareup.picasso.Request

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    val imageUrl = "https://www.w3schools.com/w3images/avatar2.png"
    val Request_PH = 2907
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.backBtn.setOnClickListener(View.OnClickListener {
            val profileActivityIntent = Intent(this@ProfileActivity, HomeActivity :: class.java)
            startActivity(profileActivityIntent)
        })

        //Picasso Library Build
        Picasso.get()
            .load(imageUrl)
            .placeholder(R.drawable.avatarprofile) // Optional placeholder image while loading
            .error(R.drawable.warning) // Optional error image if the load fails
            .into(binding.imgCard)

        binding.txtContact.setOnClickListener(View.OnClickListener {
            if(android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                if(ContextCompat.checkSelfPermission( this@ProfileActivity, Manifest.permission.CALL_PHONE)
                    != PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(this@ProfileActivity, arrayOf(Manifest.permission.CALL_PHONE),Request_PH)
                }
                else{
                    val number = binding.txtContact.text.toString()
                    val call = Uri.parse("tel: " + number)
                    val callActivityIntent = Intent(Intent.ACTION_CALL, call)
                    startActivity(callActivityIntent)
                }
            }
            else{
                val number = binding.txtContact.text.toString()
                val call = Uri.parse("tel: " + number)
                val callActivityIntent = Intent(Intent.ACTION_CALL, call)
                startActivity(callActivityIntent)
            }
        })
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode){
            Request_PH -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    val number = binding.txtContact.text.toString()
                    val call = Uri.parse("tel: " + number)
                    val callActivityIntent = Intent(Intent.ACTION_CALL, call)
                    startActivity(callActivityIntent)
                } else {
                    Toast.makeText(this@ProfileActivity, "Permission Denied", Toast.LENGTH_LONG)
                        .show()
                }
            }
        }
    }
}