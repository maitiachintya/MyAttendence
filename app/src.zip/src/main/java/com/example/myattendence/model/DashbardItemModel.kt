package com.example.myattendence.model

data class DashbardItemModel(val img : Int, val text : String)
