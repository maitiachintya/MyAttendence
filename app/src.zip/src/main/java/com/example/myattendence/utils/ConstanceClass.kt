package com.example.myattendence.utils

class ConstanceClass {
    companion object{
        val base_URL = "https://www.tenacioushub.com/"
    }
}