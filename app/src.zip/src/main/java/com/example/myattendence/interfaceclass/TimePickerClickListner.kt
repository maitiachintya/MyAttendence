package com.example.myattendence.interfaceclass

interface TimePickerClickListner {
    fun onTimePickerClickListner(hour : Int, min : Int)
}