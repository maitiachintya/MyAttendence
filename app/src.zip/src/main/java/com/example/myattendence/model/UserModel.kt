package com.example.myattendence.model

data class UserModel(val status : String, val msg : String, val id : Int,
                     val name : String, val admin_type : String, val ecode : String,
                     val timing : String)
