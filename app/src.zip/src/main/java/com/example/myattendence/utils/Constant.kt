package com.example.myattendence.utils

class Constant {
    companion object{
        val emailid = "email"
        val password = "password"
        val islogin = "login"
        val userModel = "UserModel"
        val isSaved = "Save"
    }
}