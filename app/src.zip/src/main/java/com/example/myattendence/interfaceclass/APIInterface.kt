package com.example.myattendence.interfaceclass

import com.example.myattendence.model.UserModel
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface APIInterface {
    @GET("/api.php?")
    open fun getUser( @Query("action") action : String,
                        @Query("username") username : String,
                            @Query("password") password : String) : Call<UserModel>


}