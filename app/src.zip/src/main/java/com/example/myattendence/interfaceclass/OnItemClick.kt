package com.example.myattendence.interfaceclass

interface onItemClick {
    fun onItemClick(pos : Int)
}